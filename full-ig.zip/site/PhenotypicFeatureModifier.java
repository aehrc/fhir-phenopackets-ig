package http://ga4gh.org/fhir/phenopackets/ImplementationGuide/ga4gh.fhir.phenopackets-0.1.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PhenotypicFeatureModifier {

}
